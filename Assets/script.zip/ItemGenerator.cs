using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemGenerator : MonoBehaviour
{
    public GameObject bombPrefab;
    public GameObject baloonPrefab;

    public Vector2 spawnRangeX1 = new Vector2(-157.4f, 159.4f); // x 좌표 범위
    public Vector2 spawnRangeZ1 = new Vector2(-35.29f, -21.35f); // z 좌표 범위
    public Vector2 spawnRangeX2 = new Vector2(0f, 5f);  // 두 번째 x 좌표 범위
    public Vector2 spawnRangeZ2 = new Vector2(0f, 5f);  // 두 번째 z 좌표 범위
    public float fixedY = 79.5f; // 고정된 y 좌표

    public int initialItemCountPerRange = 20; // 초기 생성할 아이템 개수

    // Start is called before the first frame update
    void Start()
    {
        // 초기 아이템 생성
        SpawnInitialItems(spawnRangeX1, spawnRangeZ1);
        SpawnInitialItems(spawnRangeX2, spawnRangeZ2);
    }

    // Update is called once per frame
    void SpawnInitialItems(Vector2 xRange, Vector2 zRange)
    {
        for (int i = 0; i < initialItemCountPerRange; i++)
        {
            SpawnRandomItem(xRange, zRange);
        }
    }

    void SpawnRandomItem(Vector2 xRange, Vector2 zRange)
    {
        // x 및 z 좌표를 지정된 범위에서 랜덤하게 설정
        float randomX = Random.Range(xRange.x, xRange.y);
        float randomZ = Random.Range(zRange.x, zRange.y);

        // 고정된 y 좌표로 아이템 생성
        Vector3 spawnPosition = new Vector3(randomX, fixedY, randomZ);

        // 두 가지 아이템 중에서 랜덤으로 선택
        GameObject selectedPrefab = Random.Range(0f, 1f) > 0.5f ? bombPrefab : baloonPrefab;

        // 선택된 아이템 Prefab을 인스턴스화하여 생성
        Instantiate(selectedPrefab, spawnPosition, Quaternion.identity);
    }
}