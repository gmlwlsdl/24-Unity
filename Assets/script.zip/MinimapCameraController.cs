using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinimapCameraController : MonoBehaviour
{
    public GameObject Player;
    public float offsetX = 5.0f;            // 카메라의 x좌표
    public float offsetY = 100.0f;           // 카메라의 y좌표
    public float offsetZ = -10.0f;          // 카메라의 z좌표
    public float CameraSpeed = 10.0f;       // 카메라의 속도
    Vector3 PlayerPos;                      // 플레이어의 위치

    // Update is called once per frame
    void FixedUpdate()
    {
        // 타겟의 x, y, z 좌표에 카메라의 좌표를 더하여 카메라의 위치를 결정
        PlayerPos = new Vector3(
            Player.transform.position.x + offsetX,
            Player.transform.position.y + offsetY,
            Player.transform.position.z + offsetZ
            );

        // 카메라의 움직임을 부드럽게 하는 함수(Lerp)
        transform.position = Vector3.Lerp(transform.position, PlayerPos, Time.deltaTime * CameraSpeed);
    }
}