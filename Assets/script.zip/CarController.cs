using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarController : MonoBehaviour
{
    GameObject director;
    public float moveSpeed = 5.0f;
    public float acceleration = 2.0f; // Adjust this value to control acceleration
    public float deceleration = 5.0f; // Adjust this value to control deceleration
    public float maxSpeed = 10.0f; // Adjust this value to set the maximum speed
    public float rotationSpeed = 100.0f;

    private float currentSpeed = 0.0f;
    private float horizontalInput = 0.0f;
    private float verticalInput = 0.0f;

    public Transform FrontLeftWheel;
    public Transform FrontRightWheel;
    public Transform RearLeftWheel;
    public Transform RearRightWheel;

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Bomb")
        {
            this.director.GetComponent<GameDirector>().GetBomb();
            UnityEngine.Debug.Log("밤이랑 부딫혔다!");
        }
        else if (other.gameObject.tag == "Balon")
        {
            this.director.GetComponent<GameDirector>().GetBalon();
            UnityEngine.Debug.Log("벌룬이랑 부딫혔다!");
        }
        else
        {
            this.director.GetComponent<GameDirector>().GetCone();
            UnityEngine.Debug.Log("꼬깔이랑 부딫혔다!");
        }

        Destroy(other.gameObject);
    }

    // Start is called before the first frame update
    void Start()
    {
        this.director = GameObject.Find("GameDirector");
    }

    // Update is called once per frame
    void Update()
    {
        horizontalInput = 0.0f;
        verticalInput = 0.0f;

        if (Input.GetKey(KeyCode.W))
        {
            verticalInput = 1.0f;
        }
        else if (Input.GetKey(KeyCode.S))
        {
            verticalInput = -1.0f;
        }

        if (Input.GetKey(KeyCode.A))
        {
            horizontalInput = -1.0f;
        }
        else if (Input.GetKey(KeyCode.D))
        {
            horizontalInput = 1.0f;
        }

        // Calculate acceleration and deceleration
        float targetSpeed = verticalInput * maxSpeed;
        currentSpeed = Mathf.MoveTowards(currentSpeed, targetSpeed, acceleration * Time.deltaTime);

        // 이동 방향 설정
        Vector3 moveDirection = new Vector3(horizontalInput, 0f, currentSpeed).normalized;

        // 이동 적용
        transform.Translate(moveDirection * moveSpeed * Time.deltaTime);

        // 회전 적용
        RotateCar(horizontalInput);
    }

    void RotateCar(float input)
    {
        // 좌우 회전
        transform.Rotate(Vector3.up * input * rotationSpeed * Time.deltaTime);

        // 바퀴 회전 적용
        float wheelRotation = input * rotationSpeed * Time.deltaTime;

        RotateWheel(FrontLeftWheel, wheelRotation);
        RotateWheel(FrontRightWheel, wheelRotation);
        RotateWheel(RearLeftWheel, wheelRotation);
        RotateWheel(RearRightWheel, wheelRotation);
    }

    void RotateWheel(Transform wheelTransform, float rotationAmount)
    {
        // 바퀴 회전 적용
        wheelTransform.Rotate(Vector3.right * rotationAmount);
    }
}