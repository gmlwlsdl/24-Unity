using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameDirector : MonoBehaviour
{
    GameObject timeText;
    public float time=180.0f;
    GameObject startTimeText;
    float startTime=3f;

    protected float curHealth;
    public float maxHealth;
    Slider hpBarSlider;

    public TextMeshProUGUI startUIText;

    private bool startTextCoroutineStarted = false;

    public void timer()
    {
        
        time -= Time.deltaTime;
        string second = (time % 60).ToString("00");
        startTimeText.GetComponent<TextMeshProUGUI>().text = second;
        timeText.GetComponent<TextMeshProUGUI>().text = time.ToString("F1") + " s";
    }

    IEnumerator HideStartTextAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        startUIText.text = "";
        
    }

    public void SetUp(float amount) // HP 설정
    {
        maxHealth = amount;
        curHealth = maxHealth;
    }

    public void CheckHp()  // HP 갱신
    {
        if (hpBarSlider != null)
            hpBarSlider.value = curHealth / maxHealth;
    }

    public void Damage(float damage)  // HP 데미지 받는 함수
    {
        if (maxHealth == 0 || curHealth <= 0)
            return;
        curHealth -= damage;
        CheckHp();
        if (curHealth <= 0)
        {
            // 플레이어 사망 또는 처리할 내용 추가
        }
    }

    public void GetBomb()
    {
        time -= 10.0f;
        timeText.GetComponent<TextMeshProUGUI>().text = time.ToString("F1") + " s";
    }

    public void GetCone()
    {
        Damage(20.0f);
        CheckHp();
    }

    public void GetBalon()
    {
        time += 10.0f;
        timeText.GetComponent<TextMeshProUGUI>().text = time.ToString("F1") + " s";
    }

    // Start is called before the first frame update
    void Start()
    {
        timeText = GameObject.Find("Time");
        startTimeText = GameObject.Find("StartTime");
        hpBarSlider = GameObject.Find("Slider").GetComponent<Slider>();

        startUIText = GameObject.Find("StartText").GetComponent<TextMeshProUGUI>();
    }

    // Update is called once per frame
    void Update()
    {
        if (startTime > 0)
        {
            startTime -= Time.deltaTime;

            string second = startTime.ToString("0");
            startTimeText.GetComponent<TextMeshProUGUI>().text = string.Format("{0}", second);

        }

        if (startTime <= 0 && !startTextCoroutineStarted)
            { 

                startTimeText.SetActive(false);
                startUIText.text = "start!";
            
            StartCoroutine(HideStartTextAfterDelay(1.0f));  // 1초 후에 숨김
            startTextCoroutineStarted = true;
            
                timer();
            
            

        }
        

    }
}
